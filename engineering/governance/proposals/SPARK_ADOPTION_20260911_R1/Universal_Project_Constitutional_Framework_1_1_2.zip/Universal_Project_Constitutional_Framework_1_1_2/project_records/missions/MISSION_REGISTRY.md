# Mission registry

Each `MIS-<UUID4>/mission.json` in this directory is a separate mission record. Run `python3 governance/tools/framework.py index` for a readable list; copying or indexing records does not grant authority. Use `python3 governance/tools/framework.py new-mission --title "<short title>"` to create a folder and templates, then record the actual grant before claiming readiness.
