# Acceptance records

Store the Operator-authorized acceptance record here under a unique filename. Use the template in `governance/templates/adoption.json`, fill actual source evidence and exact member hashes, and preserve prior acceptance records. Point `ACTIVE_ADOPTION.json` to the accepted record and its SHA-256 only after authorization. The validator has no adoption command.

An editable local pointer and acceptance file detect ordinary drift; they do not authenticate a human or resist a writer who can rewrite every record and tool. Keep the accepted record or its digest in an independently trusted location when stronger fidelity is needed; `check --expected-adoption-sha256` compares with that supplied digest.
