# Project source register

Status: empty source index; no project properties are established by this starter.

| Decision or property | Actual authoritative source | Scope and source-established status | Index or decision-record reference |
|---|---|---|---|

Preserve source wording separately from agent interpretation. Use the Design Authority Index Schema for indexed decisions. Missing rows do not revoke decisions. The optional Standing Design Discretion proposal remains unadopted unless a distinct source authorizes it.
