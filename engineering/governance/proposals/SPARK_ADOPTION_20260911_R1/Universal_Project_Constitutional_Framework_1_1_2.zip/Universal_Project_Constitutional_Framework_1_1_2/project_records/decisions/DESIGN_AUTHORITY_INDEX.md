# Design Authority Index

Decision rows live in [dai/](dai/), one JSON file per row. Run `python3 governance/tools/framework.py index` for a readable table of all rows and the provisional review queue; it also checks each row's identity, kind, status, source and provisional fields. This file and that output are retrieval aids, not a second authority. Missing index entries do not revoke source decisions.

The supplied [DAI-ENVELOPE-01](dai/DAI-ENVELOPE-01.json) is PROPOSED. It changes status only from the actual setup decision under A5.3. New rows use A2.3 identifiers and the fields in D; creators preserve other actors' rows. Ambiguous Operator input is preserved separately in [operator_input/](operator_input/README.md).
