# Validation — 1.1.2

All **56 command-level fixture checks produced their expected results** in an isolated copy. Reproduce them with `python3 governance/validation/replay_checks.py`; add `--write-results` to refresh [validation/RESULTS.json](validation/RESULTS.json), which holds each case's output. Positive results and intentional negative results are distinguished by expected exit status. The suite runs under whichever Python launches it, and was also run from `/` with only `python3` on the path.

| Area | Verified |
|---|---|
| Structure and identifiers | Seven members, relative links and home entries, LF bytes and exact hashes; all 258 identifiers from 1.0.0 are present (the suite fails otherwise), 276 in total. Works when launched from an unrelated directory. |
| Startup | Three bindings alone fail readiness; an invalid dependency scope and the removed `NOT_CHEAPLY_REVERSIBLE` option fail; the explicit choices, channel source and availability, a first grant with actors, duration and conditions, and the DAI disposition are all required. A manual-review timing fixture passes. No provider or actual authority is verified. |
| Entrypoints | Ordinary edits around the A6 block pass. Removing or altering the block fails, and so does deleting `AGENTS.md`. A `CLAUDE.md` missing a required import or importing a missing file fails; an absent `CLAUDE.md` is allowed. An oversized `AGENTS.md` warns without failing. |
| Records | Mission scaffolds create distinct UUID4 folders with `checkpoint.md`, `closeout.md` and an empty log, and invent no grant. `index` renders rows and titled missions. It rejects an invalid status, a SETTLED row without a source, a provisional row missing containment fields, and an identifier/filename mismatch; a complete provisional row appears in the review queue. |
| Adoption fidelity | Exact accepted content passes. An appended fake assurance waiver fails. In-place hash regeneration is refused after acceptance. Manually regenerating the member list does not bypass the accepted-member comparison. |
| Acceptance drift | Changed acceptance bytes fail the pointer digest. Rewriting the pointer too still fails when the original trusted digest is supplied. Removing the pointer leaves detectable acceptance history. |
| Candidate editing | A separately named candidate hash file can be produced without changing active hashes or acceptance records. It cannot overwrite the active member list. |
| Line endings | CRLF conversion fails; restoring the accepted LF bytes passes. Outside the suite: a Git checkout with `core.autocrlf=true` verifies with the supplied attributes, and `git check-attr` shows governed text pinned to LF while a binary file under `governance/` is not marked as text. |
| JSONL | Valid hold and failure events and distinct updates to one issue pass. Duplicate event IDs, human-label keys, missing failure facts, cross-mission identity, timezone-free timestamps and the retired `COMPETING_COURSES` branch reason fail; the two new C11.2 branch reasons validate. |

Live Codex and Claude loading, provider access, actual Operator authentication, runtime enforcement, co-owner governance and net productivity gains were not tested. Acceptance fixtures are explicitly synthetic, not real adoption.

## Bounded workflow review

Before adoption, I0.1 lets setup proceed on the direct instructions of the human directing the project. Routine work loads external rules through a fixed, checked entrypoint plus editable project conventions. First-mission readiness checks actual source records without granting work. Required assurance uses the explicit dependency choice and channel-appropriate finite limits. Provisional properties have a concrete DAI destination and a generated review queue. Ambiguous Operator input has a preserved home, and TDRs, reviews, dispensations and checkpoints have fixed homes under the three constitutional homes. The duty holder serializes mission event appends. Same-reviewer repair verification and bounded review rounds remain unchanged. Adoption binds exact configured members in a separate record; drift blocks affected reliance, and candidate editing does not update acceptance. Non-Git closeout uses destination and content identity. Each path retains an explicit completion or unresolved-state exit.

Imports and read instructions are not a guarantee of agent adherence; Codex in particular reads the governing files only by following the entrypoint instruction. Entirely local editable tooling and records are not a tamper-resistant authority system; stronger fidelity requires a separately trusted acceptance digest or record.

## Drafting corrections (1.1.2)

The C11, I16, A5.1 and conventions changes were reviewed textually against representative tasks, not tested as agent behavior:

- **Ordinary engineering:** an authorized implementation choice between defensible options stays with its owner; no branch arises unless authority, interpretation or required assurance is missing.
- **Routine convention update:** one source-bearing entry in the conventions record, with a DAI row only when D.6 applies.
- **Solution or amendment drafting:** the review scope is fixed first; repairs recheck only affected requirements.
- **Required assurance unavailable:** the dependent-transition hold remains a C11.2 branch, and nothing permits a self-waiver.

