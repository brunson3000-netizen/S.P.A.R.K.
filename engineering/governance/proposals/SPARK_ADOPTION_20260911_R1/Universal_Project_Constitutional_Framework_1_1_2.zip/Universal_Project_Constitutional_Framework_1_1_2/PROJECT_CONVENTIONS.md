# Project conventions

Record the project's actual package manager, commands, layout, coding conventions and working practices. No defaults are invented by this template. Ordinary updates within an authorized mission do not amend the governing framework; authority changes still follow C9. Entries create no project property. Preserve each entry's source here; index a convention in the Design Authority Index only when D.6 requires it.

Source values: `Operator: <locator>` for Operator direction, or `Agent-recorded` for an engineering fact an agent established.

## Commands

| Purpose | Command | Source |
|---|---|---|
| Setup / install | | |
| Build | | |
| Test | | |
| Lint / format | | |
| Run | | |

## Layout

| Path | Holds | Source |
|---|---|---|

## Workspaces and integration

| Convention | Detail | Source |
|---|---|---|
